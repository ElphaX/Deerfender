#!/bin/bash

## Filter Function to run the search for dealers based off a time and day
filter() {
	echo 'What day are you looking for?'
			## Create menu options based of all available files with schedule wildcard in current directory
                        select filename in *schedule
                                do
                                        date=${filename:0:4}
					## Get all applicable times based off Notes to remove redundancy
                                        times=`grep -E $date ../Player_Analysis/Notes_Player_Analysis | awk -F' ' {'print $2'}`
                                        echo 'And what time on ' $date '?'
                                        select timestamp in $times
                                                do
							time_selected=`sed -e 's/AM/ AM/g' -e 's/PM/ PM/g' <<< $timestamp`
                                                        dealer=`cat $filename | grep -i "$time_selected" | awk -F'\t' '{print $3}'`
							echo "${date} ${timestamp} ${dealer}" >> $output
							break;
                                                done
                                        break;
                                done
	echo 'Done investigating and want to read the output?'
			## Finish filter or restart the function to save time
			select concluder in Show_Output Add_another
				do
					case $concluder in
						"Show_Output")
							cat $output
							break;;
						*)
							filter
						;;
					esac
				done
}
## Globally declaring the output file
output=Dealers_working_during_losses

## Check if file exists
if test -f "$output"
	then
        echo 'Continue from previous investigation or looking to clear analysis data?'
        options=("Continue" "Clear_Data")
        select option in "${options[@]}"
		do
			case $option in
				"Clear_Data")
        	                	rm Dealers_working_during_losses
					break
					;;
				*)
					filter
					break
					;;
                	esac
        	done
else
        filter
fi
